// QQregDlg.cpp : implementation file
//

#include "stdafx.h"
#include "QQreg.h"
#include "QQregDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include <MsHTML.h>
/////////////////////////////////////////////////////////////////////////////
// CQQregDlg dialog

CQQregDlg::CQQregDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CQQregDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CQQregDlg)
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CQQregDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CQQregDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CQQregDlg, CDialog)
	//{{AFX_MSG_MAP(CQQregDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTREG, OnButreg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CQQregDlg message handlers

BOOL CQQregDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CQQregDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CQQregDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CQQregDlg::OnButreg() 
{
	// TODO: Add your control notification handler code here
	HRESULT hr;

	IWebBrowser2* m_pBrowser;
	//����COM���
	hr = CoCreateInstance (CLSID_InternetExplorer, NULL, CLSCTX_LOCAL_SERVER, 
		IID_IWebBrowser2, (LPVOID *)&m_pBrowser);

	VARIANT_BOOL pBool=TRUE;
	//��ʾ�������
	m_pBrowser->put_Visible(pBool);

	if (hr == S_OK) {
		COleVariant vaURL(TEXT("http://reg.qq.com/"));
		VARIANT vNull;
		VariantInit(&vNull);
		vNull.vt = VT_BSTR;
		vNull.bstrVal = NULL;
		//���ָ����ַ
		m_pBrowser->Navigate2(vaURL,&vNull,&vNull,&vNull,&vNull) ; 

		READYSTATE emReadState;
		//�ȴ���ҳ��
		m_pBrowser->get_ReadyState(&emReadState);
		while (READYSTATE_COMPLETE != emReadState)
		{
			m_pBrowser->get_ReadyState(&emReadState);
			Sleep(500);
		}
		
		IDispatch* pDispDocument;
		hr=m_pBrowser->get_Document(&pDispDocument);
		IHTMLDocument2* pHTMLDocument2;
		//���HTMLDocument2�ӿ�
		hr = pDispDocument->QueryInterface( IID_IHTMLDocument2,(void**)&pHTMLDocument2 );
		
		if (hr == S_OK) {
			IHTMLElementCollection* pColl = NULL;
			//���Ԫ�ؼ���ElementCollection�ӿ�
			hr = pHTMLDocument2->get_all(&pColl);

			if (hr == S_OK && pColl != NULL) {
				long lNumElem;
				//��ȡԪ�ؼ��ϳ���
				hr = pColl->get_length( &lNumElem );
								
				if ( hr == S_OK ) {
					unsigned short cInputText = 0;	//�����ı��ļ�����
					unsigned short cSel = 0;		//ѡ���б�����
					//����Ԫ��
					for (int i = 0 ; i < lNumElem ; ++i) {
						VARIANT varIndex;
						varIndex.vt = VT_UINT;
						varIndex.lVal = i;
						VARIANT var2;
						VariantInit( &var2 );
						IDispatch* pDispItem;
						//���Ԫ��Dispitem
						hr = pColl->item( varIndex, var2, &pDispItem );

						if ( hr == S_OK ) {
							IHTMLElement* pElem;
							//��ó�����ҳԪ��HTMLElement�ӿ�
							hr = pDispItem->QueryInterface(IID_IHTMLElement,(void **)&pElem);
							if ( hr == S_OK ) {

								//��ͼ��������ı���Ԫ�ؽӿ�
								IHTMLInputTextElement* pUserInput;
								hr = pDispItem->QueryInterface(IID_IHTMLInputTextElement, (void **)&pUserInput );
								if ( hr == S_OK ) {
									//��ѯ�����ı���ĵ�name����ֵ
									/*
									pUserInput->get_name(&bstr);
									CString strName;
									strName=bstr;
									*/
									CString strInput[4] = {TEXT("�ǳƴ���"), 
														   TEXT("�����ȷ������"), 
														   TEXT("�����ȷ������"), 
														   TEXT("��֤��XXXX")};
									BSTR bstr = strInput[cInputText++].AllocSysString();
									pUserInput->put_value(bstr);						
									pUserInput->Release();
								}

								//��ͼ���ѡ���б��ӿ�
								IHTMLSelectElement* pSel;
								hr = pDispItem->QueryInterface(IID_IHTMLSelectElement, (void **)&pSel);
								if(hr == S_OK) {
									if(cSel++ <= 2)
										pSel->put_selectedIndex(1L);
									pSel->Release();
								}

								//��ͼ��ó�����Ԫ�ؽӿ�
								IHTMLAnchorElement* pSubAnchor;
								hr = pDispItem->QueryInterface(IID_IHTMLAnchorElement, (void **)&pSubAnchor);
								if(hr == S_OK) {
									BSTR bstr;
									pElem->get_id(&bstr);
									CString strID;
									strID = bstr;
									if(strID == "a_submit")
										pElem->click();
									pSubAnchor->Release();
								}

								//��ͼ��ñ���Ԫ�ؽӿ�
								/*
								if(pForm == NULL) {
									BSTR bstr;
									hr = pElem->get_tagName(&bstr);
									CString strTag; 
									strTag = bstr;
									if(strTag == "FORM") 
										hr = pDispItem->QueryInterface(IID_IHTMLFormElement, (void**)&pForm);
									pForm->submit();
									pForm->Release();
								}
								*/

								pElem->Release();
							}
						pDispItem->Release();
						}
					}//forѭ������Ԫ�ؼ���
				}
				pColl->Release();
			}
			pHTMLDocument2->Release();
			pDispDocument->Release();
		}
		m_pBrowser->Release();
	}
}
