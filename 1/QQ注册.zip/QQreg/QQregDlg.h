// QQregDlg.h : header file
//

#if !defined(AFX_QQREGDLG_H__5BB2208C_9AB4_4EE9_A992_B2CB0CF8FCA0__INCLUDED_)
#define AFX_QQREGDLG_H__5BB2208C_9AB4_4EE9_A992_B2CB0CF8FCA0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CQQregDlg dialog

class CQQregDlg : public CDialog
{
// Construction
public:
	CQQregDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CQQregDlg)
	enum { IDD = IDD_QQREG_DIALOG };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CQQregDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CQQregDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButreg();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_QQREGDLG_H__5BB2208C_9AB4_4EE9_A992_B2CB0CF8FCA0__INCLUDED_)
