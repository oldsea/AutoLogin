// QQreg.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "QQreg.h"
#include "QQregDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CQQregApp

BEGIN_MESSAGE_MAP(CQQregApp, CWinApp)
	//{{AFX_MSG_MAP(CQQregApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CQQregApp construction

CQQregApp::CQQregApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CQQregApp object

CQQregApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CQQregApp initialization

BOOL CQQregApp::InitInstance()
{
	AfxEnableControlContainer();

	// Standard initialization

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif
	
	//��ʼ��COM
	HRESULT hr = ::CoInitialize(NULL);

	CQQregDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
	}
	else if (nResponse == IDCANCEL)
	{
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

int CQQregApp::ExitInstance() 
{
	// TODO: Add your specialized code here and/or call the base class
	::CoUninitialize();
	return CWinApp::ExitInstance();
}
